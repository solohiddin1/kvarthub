
import Login from './Login'

const Home = () => {
  return (
    <div>
      <Login/>
    </div>
  )
}

export default Home
