import HeaderImg from "./header-img.png"
import GoogleLogo from "./google-img.svg"

export {HeaderImg, GoogleLogo}